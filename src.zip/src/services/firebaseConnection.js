import firebase from 'firebase/app';
import 'firebase/auth';
import 'firebase/firestore';



const firebaseConfig = {
  apiKey: "AIzaSyCf92HBRnWL3WSgMOdW5lbdefYpRmbRABY",
  authDomain: "sistema-17453.firebaseapp.com",
  projectId: "sistema-17453",
  storageBucket: "sistema-17453.appspot.com",
  messagingSenderId: "153183002139",
  appId: "1:153183002139:web:dd6c0d53c9a5ae5e4722be",
  measurementId: "G-H8373P7DB9"
};
if(!firebase.apps.length){
  firebase.initializeApp(firebaseConfig);
  
}

export default firebase;